
### Step 1: Install Required Libraries (If not already installed)

In your project’s root directory, create a `requirements.txt` file containing the following:

```txt
Django>=4.0,<5.0
djangorestframework
psycopg2-binary  # If using PostgreSQL
gunicorn  # For production deployment (optional)
django-crispy-forms  # For enhanced form rendering (optional)
celery  # For task queue (optional)
django-environ  # For environment variables (optional)
```

Then, install the requirements using:

```bash
pip install -r requirements.txt
```

---

### Step 2: Create Superuser (Admin User)

1. Open your terminal or command prompt.
2. Navigate to the project directory.
3. Run the following command to create a superuser (admin user):

   ```bash
   python manage.py createsuperuser
   ```

4. Enter the required details (username, email, password) for the superuser account.

   - **Username**: `admin`
   - **Email**: `admin@example.com`
   - **Password**: `yourpassword`

> **Note**: Make sure to remember these credentials as you will use them to log in to the admin dashboard.

---

### Step 3: Run the Django Development Server

1. Open your terminal and navigate to your Django project folder.
2. Run the development server with the following command:

   ```bash
   python manage.py runserver
   ```

3. The server should now be running at `http://127.0.0.1:8000/`. You should see a message like:

   ```bash
   Starting development server at http://127.0.0.1:8000/
   Quit the server with CONTROL-C.
   ```

---

### Step 4: Access the Admin Panel in the Browser

1. Open your browser and go to the following URL:

   ```bash
   http://127.0.0.1:8000/admin/
   ```

2. You will be directed to the login page.

---

### Step 5: Log in to the Admin Panel

1. On the login page, enter the **username** and **password** that you set up for the superuser.

   - **Username**: `admin`
   - **Password**: `yourpassword`

2. Click **Log in**.

---

### Step 6: Admin Panel Features

Once logged in, you will have access to:

- **Manage Users**: Add, modify, and delete users.
- **Manage Employee Data**: View, edit, or delete employee details.
- **View Reports**: Generate and view reports on various aspects of the employee management system.
- **Manage Permissions**: Grant or revoke permissions to other users.
